# COIN Lite — Functional Test Specification

## Test Equipment Required
- USB-C cable
- Multimeter
- Smartphone with Bluetooth (for audio test)

## Tests (all must PASS)

### TEST 1: Power Supply
1. Connect USB-C cable
2. Measure voltage at U3 output pad: **PASS if 3.2V - 3.4V**
3. Disconnect USB-C

### TEST 2: Battery Charge
1. Connect USB-C with battery connected
2. TP4054 CHRG pin should go LOW (charging)
3. Measure battery voltage: **PASS if 3.0V - 4.2V**

### TEST 3: Button & LED
1. Short-press button (SW1)
2. LED1 should light up (any color)
3. **PASS if LED responds to button**

### TEST 4: Audio Output
1. Power on device
2. Send test tone via Bluetooth or I2S test mode
3. Listen for audio from speaker
4. **PASS if audio is audible and clear (no distortion at moderate volume)**

### TEST 5: Enclosure Integrity
1. Shake device gently — no rattling
2. USB-C port accessible through case cutout
3. Button accessible through case cutout
4. LED visible through top window
5. **PASS if all access points functional and no loose parts**

## Reject Criteria
- Any test FAIL → unit is rejected
- Solder bridges visible → rework required
- Battery polarity reversed → unit scrapped (do not rework)
- Cracked enclosure → replace case only

## Label
Apply small label (if provided) with:
- Model: KOE-COIN-LITE
- Serial: CL-NNNN (sequential)
- Date: YYYY-MM-DD

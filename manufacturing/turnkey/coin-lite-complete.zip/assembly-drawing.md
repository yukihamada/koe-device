# COIN Lite — Assembly Drawing

## Product: Koe COIN Lite Wireless Audio Receiver
## PCB: Circular Ø26mm, 2-layer, 1.0mm FR-4
## Enclosure: Cylindrical Ø30mm x 18.5mm, 2-piece snap-fit

---

## Assembly Order

### Step 1: SMT Assembly (machine)
All components in BOM marked "SMT" are placed by pick-and-place machine.
Use CPL.csv for placement coordinates.

### Step 2: Visual Inspection
- Check all solder joints under 10x magnification
- Verify no solder bridges on ESP32-C3-MINI-1 (U1) or USB-C (J1)
- Confirm LED1 (WS2812B) orientation: corner notch = pin 1

### Step 3: Power Test (before manual assembly)
- Connect USB-C cable to J1
- Measure VCC on U3 output: must read 3.3V ±0.1V
- If LED1 flashes, MCU is alive (good)
- If no voltage: check U3, U4 solder joints

### Step 4: Battery Wiring
```
  Battery (BT1): 301020 LiPo 3.7V 300mAh
  
  ┌──────────────┐
  │  BT+    BT-  │  ← PCB pads (top side, near edge)
  │   ↑      ↑   │
  │  RED   BLACK  │  ← Battery wires
  └──────────────┘
  
  CRITICAL: Verify polarity with multimeter before soldering!
  Red wire → BT+ pad
  Black wire → BT- pad
  Wrong polarity = dead unit (TP4054 damaged)
```
- Strip 2mm of insulation from battery wires
- Tin the wire ends and PCB pads
- Solder red to BT+, black to BT-
- Apply Kapton tape over solder joints

### Step 5: Speaker Wiring
```
  Speaker (SPK1): 15x10mm 8ohm 0.5W
  
  ┌──────────────┐
  │ SPK+   SPK-  │  ← PCB pads
  │   ↑      ↑   │
  │  RED   BLACK  │  ← 30AWG wires (40mm length)
  └──────────────┘
       ↓      ↓
  ┌──────────────┐
  │  +        -  │  ← Speaker terminals
  └──────────────┘
```
- Cut 2x 40mm lengths of 30AWG silicone wire (red + black)
- Solder to PCB SPK+/SPK- pads
- Solder other ends to speaker terminal pads

### Step 6: Firmware Flash
- Connect USB-C to computer
- Flash firmware binary (see flash-instructions.md)
- Verify: LED should show brief color sequence, then breathe blue

### Step 7: Functional Test
- Run tests per test-spec.md
- All 5 tests must PASS

### Step 8: Final Mechanical Assembly
```
  Enclosure Cross-Section:
  
  ┌─────────────────┐  ← Top case (snap-fit)
  │  ▓▓▓ Speaker ▓▓▓│  ← Speaker facing up (sound holes)
  │                  │
  │  ═══ PCB ═══════│  ← PCB on standoffs (components face UP)
  │  ████ Kapton ███│  ← Kapton tape insulation
  │  ░░░ Battery ░░░│  ← Battery in bottom cavity
  └─────────────────┘  ← Bottom case
  
  USB-C port aligns with bottom case cutout (Y=0 side)
  Button aligns with right side cutout
```

1. Place battery in bottom case (flat, wires routed to side)
2. Apply Kapton tape over PCB bottom (covers battery contact area)
3. Set PCB on standoff posts (4 posts, components facing UP)
4. Route speaker wires through to top compartment
5. Place speaker in top case cavity (face up toward grille holes)
6. Press top case onto bottom case until snap-fit clicks

### Step 9: Final Verification
- Press button: device powers on, LED lights up
- Press button again: device powers off
- Connect USB-C: charging LED behavior visible
- Shake test: no rattling (battery and speaker secure)

# COIN Lite — Firmware Flash Instructions

## Chip: ESP32-C3-MINI-1
## Interface: USB-C (built-in USB-JTAG on ESP32-C3)

## Option A: Using esptool (recommended for manufacturing)

### Setup (once)
```bash
pip install esptool
```

### Flash each unit
```bash
esptool.py --chip esp32c3 --port /dev/ttyACM0 --baud 460800 \
  write_flash 0x0 firmware.bin
```

### Verify
```bash
esptool.py --chip esp32c3 --port /dev/ttyACM0 verify_flash 0x0 firmware.bin
```

## Option B: Using espflash (alternative)
```bash
espflash flash --chip esp32c3 --port /dev/ttyACM0 firmware.bin
```

## Boot Mode Entry (if device doesn't auto-enter flash mode)
1. Hold BOOT button (if accessible) while connecting USB-C
2. Or: connect USB-C, device should auto-enumerate as USB-JTAG

## Post-Flash Verification
1. Disconnect and reconnect USB-C
2. Device should boot: LED flashes briefly then breathes blue
3. Device appears as BLE peripheral named "Koe-XXXX"

## Batch Flashing
For multiple units, use a USB hub:
```bash
for port in /dev/ttyACM*; do
  esptool.py --chip esp32c3 --port $port --baud 460800 \
    write_flash 0x0 firmware.bin &
done
wait
echo "All units flashed"
```

## Firmware Binary
- File: `firmware.bin` (in this directory)
- If not present: build from source:
  ```bash
  cd koe-device/firmware/coin-lite
  cargo build --release
  espflash save-image --chip esp32c3 --merge \
    target/riscv32imc-esp-espidf/release/koe-coin-lite firmware.bin
  ```
